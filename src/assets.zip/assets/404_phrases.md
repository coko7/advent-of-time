0 1 1 2 3 5 8 13 21 34 55
43,252,003,274,489,856,000. That's how many different cube permutations are possible with a 3x3x3 Rubik's Cube.
6. 28. 496. 8128.
AAAAAAAAAAAAAA. that ur reaction?
[Aaron Swartz](https://en.wikipedia.org/wiki/Aaron_Swartz) was an Internet [hacktivist](https://en.wikipedia.org/wiki/Hacktivism) who thought for free and open access to information
Actually, [PowerShell](https://learnxinyminutes.com/powershell) is not so bad...
Alacri*tty*, ki*tty*, ghos*tty*. Ever noticed the `tty` at the end of each?
[Alan Turing](https://en.wikipedia.org/wiki/Alan_Turing) was a brilliant mathematician who played a big part in cracking the [Enigma machine](https://en.wikipedia.org/wiki/Enigma_machine)
[AlternativeTo](https://alternativeto.net) is a great site to find alternatives to software you use
Always thought JS stood for *Just Shit* 💩
An interesting fact about the [Scoville scale](https://en.wikipedia.org/wiki/Scoville_scale): Toxins and peppers are scored using the same unit
Another day, another memory leek 🥦 (its broccoli, i know)
[Big Sky Software](https://bigsky.software/)
Bill Joy created vi in 1976, Bram Moolenar released Vim in 1991 and NeoVim started in 2015
[Bjarne Stroustrup](https://en.wikipedia.org/wiki/Bjarne_Stroustrup) designed [C++](https://en.wikipedia.org/wiki/C%2B%2B) in 1985
[Blender](https://www.blender.org/) is one of the largest open-source projects out there!
[Brainfuck](https://en.wikipedia.org/wiki/Brainfuck) is an esotheric programming language with the smallest instruction set
[Brendan Eich](https://en.wikipedia.org/wiki/Brendan_Eich) created [JavaScript](https://en.wikipedia.org/wiki/JavaScript) in 1995
<button onclick="alert('you actually did it, now plz leave')">CLICK ME MOTHERFUCKER</button>
🐝 bzzz bzzz bzzzzzzzzzzz
[Candy Box 2](https://candybox2.github.io/) is a really great idle game 🍬
[Careware](https://en.wikipedia.org/wiki/Careware) refers to software licensed in a way that benefits a charity
[Celeste](https://www.celestegame.com/) is (objectively) the best (platformer) game 🍓
[Charles Babbage](https://en.wikipedia.org/wiki/Charles_Babbage) invented the [Difference engine](https://en.wikipedia.org/wiki/Difference_engine) in the 1820s
Now, watch [this](https://youtu.be/72y2EC5fkcE) *(it's programming porn if you ask me)*
Checkout [Sebastian Lague](https://www.youtube.com/channel/UCmtyQOKKmrMVaKuRXz02jbQ) on YouTube!
Checkout [ThePrimeagen](https://www.twitch.tv/theprimeagen) on Twitch!
Check out the [Turing Complete game](https://store.steampowered.com/app/1444480/Turing_Complete/) on Steam!
check this out: [https://en.wikipedia.org/wiki/Hyperoperation](https://en.wikipedia.org/wiki/Hyperoperation)
[COBOL](https://en.wikipedia.org/wiki/COBOL) is a programming language invented by [Grace Hopper](https://en.wikipedia.org/wiki/Grace_Hopper) in 1960 and was primarly made for salesmen
[Conway's Game of Life](https://youtu.be/eMn43As24Bo) only has four basic rules but that's enough to make it Turing Complete
[Cooklang](https://cooklang.org/) is a very nice way to store your cooking recipes 🍳
Craving for some pizza right now 🍕 *(what about you?)*
[dav1d](https://code.videolan.org/videolan/dav1d) is an AV1 decoder by [VideoLAN](https://www.videolan.org/) with over 210,000 lines of assembly written by hand!
Did I write all of these myself? Of course I did. <br/>What do you think I do with my life? Touch grass or somethin'? <br/>I am a programmer, I live in a cave.
20 moves is all you need to solve any Rubik's cube scramble? Its called [God's Number](https://ruwix.com/the-rubiks-cube/gods-number/)
Minecraft's redstone is Turing Complete? It means you can theoretically make Minecraft inside of Minecraft 🤯
"Directory" and "Folder" refer to the same thing but make sure you use the right one depending on who you hang out with
Does it make sense to support Auth before HTTPs?
Do you believe me if I tell you I have been writing these messages for the past hour?
**Hoorse** is a talking horse 🐴
[The Truth About The Fast Inverse Square on N64](https://youtu.be/tmb6bLbxd08)
Do you know that the longest rainfall on Earth lasted for ***2 MILLION YEARS?*** Its called the Carnian pluvial episode ☔
Dynamic routing is not as easy as I thought...
[Edsger Wybe Dijkstra](https://en.wikipedia.org/wiki/Edsger_W._Dijkstra) was a Dutch computer scientist famous for creating the shortest path algorithm and pioneering structured programming
[Edward Snowden](https://en.wikipedia.org/wiki/Edward_Snowden) is a former [NSA](https://en.wikipedia.org/wiki/National_Security_Agency) member and a [whistleblower](https://en.wikipedia.org/wiki/Whistleblowing) who leaked information about global surveillance programs.
Elephants 🐘
Ever had a TTS engine read you an RFC? Did this with [5246](https://www.rfc-editor.org/rfc/rfc5246), dumb idea, i gotta say
Ever heard about [IP over Avian Carriers](https://en.wikipedia.org/wiki/IP_over_Avian_Carriers)?
[F/LOSS](https://en.wikipedia.org/wiki/Free_and_open-source_software) stands for: 🦙 Fluffy Llamas Organizing Salsa Saturdays
foo bar baz quux lux pux mux tmux? [tmux](https://github.com/tmux/tmux) is lit
For password managers, I would recommend either [Bitwarden](https://bitwarden.com/) or [KeePassXC](https://keepassxc.org/)
[Fortran](https://en.wikipedia.org/wiki/Fortran) is an early programming language designed in 1957 by [John Backus](https://en.wikipedia.org/wiki/John_Backus)
[FOSDEM](https://fosdem.org) is the biggest open-source conference on Earth 🌍
Four O Four, Not Found
Quatre Zéro Quatre, c'est la misère, t'es du-per
[frame.work](https://frame.work/) laptops are really nice 💻
Offending Mexicans Any% => *"French tacos is the superior version of tacos 🌮"*
Fucking [Boltzmann brain](https://en.wikipedia.org/wiki/Boltzmann_brain) 🧠
[fzf](https://github.com/junegunn/fzf) is one of the greatest CLIs ever.
You should check out [gum](https://github.com/charmbracelet/gum) 🍭
🌳 Gaimon is the best anime protaganist
GET /404 HTTP/1.1 *(that you?)*
GET /404 HTTP/0.9 *(don't try it. I need to bring HTTP/0.9 support back up first...)*
GET /404 HTTP/2.0 *(WOHH! Slow down now. This site does not support HTTP/2.0. Maybe the reverse proxy is smart enough to handle this tho)*
[GNU](https://en.wikipedia.org/wiki/GNU) is a recursive acronym that stands for **GNU's Not Unix**
go back go back, its ded here 💀
🐝 gone
Go outside and touch grass already!
Gurfr zrffntrf ner trggvat dhvgr obevat, yrgf fcvpr guvatf hc n ovg 🌶️
<h1>🖕</h1>
<h1>WHAT? H1 out of nowhere??? Yes, it was HTML all along</h1>
[Hacknet](https://store.steampowered.com/app/365450/Hacknet/) was one of the first `programming-related` games I've played. You should check it out
Hardware keys are the best for 2FA. Checkout [Yubico](https://www.yubico.com/) 🔑
Hashing and encryption are two different concepts. You should never encrypt passwords, you should hash them!
Have you ever tasted Salmon Lasagna? You should give it a try
Honestly, [Bash](https://www.gnu.org/software/bash/manual/bash.html)' syntax sucks but it's really good for scripting
how do you like the site? Exploring every page, I see
How many custom messages do I have in store you ask? ***Billions***
How many different phrases have I wrote? Shouldn't be too hard for you to figure that out...
How many times will your refresh this? Or is it the first time we meet? I don't know. I am [stateless](https://en.wikipedia.org/wiki/Stateless_protocol).
I am running out of custom messages...
I cannot picture life without the constant thirst for learning
I could also go for some [Raclette 🧀](https://en.wikipedia.org/wiki/Raclette) right now. You into cheese?
If all programming langs are [Turing Complete](https://en.wikipedia.org/wiki/Turing_completeness), why do we have so many?
If you think a single programming language is all the world needs: Try cutting down a tree with a kitchen knife.
If you are looking for the button to go back, it's at the bottom ⬇️
If you think you know everything about the [Dunning-Kruger effect](https://en.wikipedia.org/wiki/Dunning%E2%80%93Kruger_effect) then you dont know the first thing about it
If you use binary to count with your fingers, you could go up to 32 on a single hand. With both hands, it would be 1024. And with both feet: 1,048,576
Listen to the entire Vim user manual here: [youtu.be/rT-fbLFOCy0](https://youtu.be/rT-fbLFOCy0)
I hope the image is loading for you, coz its just gold 🥇
I know you are reading this
I love this emoji: <span style="font-size: 4em;">🌌</span>
Imagine being an [Anti-Virus](https://clownstrike.lol/) and crashing the very computers you are installed on
[imgflip](https://imgflip.com/) is the best place to quickly whip out your best memes
I once designed my own encryption algorithm, I thought it was super strong, then I learned about [Kerckhoffs's principle](https://en.wikipedia.org/wiki/Kerckhoffs's_principle)
i really should do something other than writing 404 messages
I really want to try [htmx](https://htmx.org/) in one of my future projects
Is WireShark called WireShark because 🦈 sharks tend to crunch undersea network cables? Just realized that...
It only takes [45 paper folds](https://neal.fun/paper/) to get to the moon
It's easy to understand that x^0 = 1 when you realize that x^0 = x^1 / x = x / x = 1
[It's FOSS](https://itsfoss.com) is a nice website to stay up to date with the latest Linux and open-source software news (it even has some games and puzzles)
I use [Arch Linux](https://archlinux.org/) because of the AUR and coz its so damn awesome to be able to use the latest software
I used to think of programming languages like tools but I think they are closer to being raw materials
I use [Hyprland](https://hyprland.org/) btw
i use [neovim](https://neovim.io/) BY-THE-WAY
I've spent too much time on this CSS
[Jean-Baptiste Kempf](https://fr.wikipedia.org/wiki/Jean-Baptiste_Kempf) is a French computer engineer and the president of [VideoLAN](https://www.videolan.org/)
[John Carmack](https://en.wikipedia.org/wiki/John_Carmack) is the legend who made **DOOM**
[John von Neumann](https://en.wikipedia.org/wiki/John_von_Neumann) played a big part in computer architecture designs and the architecture he came up with is [still used today](https://en.wikipedia.org/wiki/Von_Neumann_architecture)
just wait 'till this shit natively supports [TLS 1.2](https://www.rfc-editor.org/rfc/rfc5246) *(never?)*
Ken Thompson and Dennis Ritchie played a very big part in the creation of [Unix](https://en.wikipedia.org/wiki/Unix)
[Learn X in Y minutes](https://learnxinyminutes.com/) is a very cool website to quickly get started with any programming language/tool
[Linus Torvalds](https://en.wikipedia.org/wiki/Linus_Torvalds) is the creator of Linux and Git, he is also the creator of the [Fuck You Nvidia meme](https://youtu.be/OF_5EKNX0Eg)
Linux was originally going to be called Freax
[Lustre](https://en.wikipedia.org/wiki/Lustre_programming_language) is a dataflow programming language that you can use to make your own computers using boolean logic
Maybe I should be the one to leave this page and start touching grass? *Naaah*
maybe i should stop writing those now
More, more, and more nonsense
🌵 moss head
no page, nothing, just a tumbleweed
nothin ther 4 sur
Technically, all of this was first written in [The Library of Babel](https://libraryofbabel.info/)
Not sure if your password is strong enough? Check out [zxcvbn](https://github.com/dropbox/zxcvbn)
Oh... Did you really think you could find out all of the messages simply by refreshing? <br/> What if I told you this was a [normal distribution](https://en.wikipedia.org/wiki/Normal_distribution)?
okay, been fun, now i get bak 2 work 👋
Okay, see you later 👋
One Kilobyte = 10^3 = 1000 ; One Kibibyte = 2^10 = 1024
[OSINT](https://en.wikipedia.org/wiki/Open-source_intelligence) is the collection and analysis of data gathered from open sources
🍍 Pineapple on pizza or using 🪟 Windows as a server, not sure which one is worse
[Programming guards](https://en.wikipedia.org/wiki/Guard_%28computer_science%29) is a great way to reduce [Indentation hell](https://www.reddit.com/r/ProgrammerHorror/comments/pm11ve/indentation_hell/) in your code
[Python](https://en.wikipedia.org/wiki/Python_programming_language) was created in 1991 by [Guido van Rossum](https://en.wikipedia.org/wiki/Guido_van_Rossum)
[QMK](https://qmk.fm/) is an Open-Source keyboard firmware that allows you to customize your keyboard using the C programming language
Real programmers dont eat quiche? I love quiche tho... Fuck the programming part, I'd rather eat quiche
Recursive Sidetracking, or Over-Automation, call it what you want `-_-`
[RollerCoaster Tycoon](https://en.wikipedia.org/wiki/RollerCoaster_Tycoon) was coded entirely in assembly
[RTFW](https://github.com/RTFW-rs), Rewrite The Fucking Wheel 🛞
Select some text in vim and try '`g?`'
Seriously, [ripgrep](https://github.com/BurntSushi/ripgrep) is very fast. I almost dont use simple `grep` anymore
Shoutout to the people behind [Gadgetbridge](https://gadgetbridge.org/), this project is simply **AWESOME**
[Solipsism](https://en.wikipedia.org/wiki/Solipsism) is the idea that only one's mind is sure to exist. I am a writer with no audience. Or, you are a reader in a vaccum
Some open-source project leaders are referred to as [Benevolent dictator for life](https://en.wikipedia.org/wiki/Benevolent_dictator_for_life)
[Spirited Away](https://en.wikipedia.org/wiki/Spirited_Away) is my all-time favorite movie
Stay up to date with latest Tech news with [Fireship](https://www.youtube.com/channel/UCsBjURrPoezykLs9EqgamOA)
[suckless.org](https://suckless.org/) is an interesting take on software development
Take a random english word, it's highly probable that `{YOUR-WORD}`.js is a valid JS framework
taking a lil break from work, why are u here?
téma la taille du rat: <span style="font-size: 10em;">🐁</span>
[TempleOS](https://en.wikipedia.org/wiki/TempleOS) is a custom Operating System programmed entirely using Holy C
The [Advent of Code](https://adventofcode.com/) is a world-renowned programming event that has been happening on every December since 2015.
The [allegory of the cave](https://en.wikipedia.org/wiki/Allegory_of_the_cave) is one fucked up idea when you think about it for too long
The 'autological' word is autological but the 'heterological' word itself is [a paradox](https://en.wikipedia.org/wiki/Grelling%E2%80%93Nelson_paradox)
The [B.A.T.M.A.N.](https://en.wikipedia.org/wiki/B.A.T.M.A.N.) is an actual routing protocol 🦇
The best collection of developer roadmaps: [roadmap.sh](https://roadmap.sh/)
The best thing about programming is when you start programming your own tools that you use daily
The best way to learn how HTTPS works: [https://howhttps.works/](https://howhttps.works/)
The [Caesar cipher](https://en.wikipedia.org/wiki/Caesar_cipher) is one of the oldest encryption algorithms, it was used by the Roman military
The color palette for this website is [Catppuccin Mocha](https://catppuccin.com/palette)
The [C programming language](https://en.wikipedia.org/wiki/C_programming_language) was designed by [Dennis Ritchie](https://en.wikipedia.org/wiki/Dennis_Ritchie) in 1972
The [Hacker's Delight](https://en.wikipedia.org/wiki/Hacker%27s_Delight) book contains a collection of bit-level and low-level programming tricks
The [halting problem](https://en.wikipedia.org/wiki/Halting_problem) is considered to be undecidable
The "Java" in JavaScript is basically click bait
The minimum number of moves required to visit every single Rubik's Cube permutation is known as the [Devil's Number](https://ruwix.com/the-rubiks-cube/gods-number/)
The observable universe has a diameter of approximately 28 [gigaparsecs](https://en.wikipedia.org/wiki/Parsec)
The One Piece is REAL 👒
The only reason I've made this site is to find a good use of [HTTP 418](https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Status/418)
The only rightful place to install Windows is inside a virtual machine. yes, i use Linux. How could you tell?
The only thing you need to create a computer from scratch a [NAND gate](https://en.wikipedia.org/wiki/NAND_gate): !(A.B)
The only true website is [The Motherfucking Website.](https://motherfuckingwebsite.com/)
The QWERTY layout was originally designed to avoid typewriters from jamming, not for optimal typing! Checkout [DVORAK](https://www.dvzine.org/)
There are [hundreds](https://distrowatch.com/dwres.php?resource=popularity) of different [Linux distros](https://en.wikipedia.org/wiki/Linux_distribution)!
There is a Vim addons for every IDE and editor apart from `nano`...
There's No Place Like [127.0.0.1](http://127.0.0.1)
These awesome cat images are provided to you thanks to [http.cat](https://http.cat/)
There's [http.cat](https://http.cat/), [httpcats.com](https://httpcats.com) and [http.dog](https://http.dog)
The source code for the 1969, [Apollo-11](https://en.wikipedia.org/wiki/Apollo_11) mission, is freely available on [GitHub](https://github.com/chrislgarry/Apollo-11)
The thing you smell each time it rains is called [Petrichor](https://en.wikipedia.org/wiki/Petrichor)
The [travelling salesman problem](https://en.wikipedia.org/wiki/Travelling_salesman_problem) is considered to be [NP-complete](https://en.wikipedia.org/wiki/NP-completeness).
The [XZ Utils backdoor](https://en.wikipedia.org/wiki/XZ_Utils_backdoor) was one of the craziest backdoors **found** in an Open-Source project
This entire webapp, as well as the HTTP implementation it sits on has been entirely written in [Rust](https://www.rust-lang.org/)
This http implem is getting better and better
[Tim Berners-Lee](https://en.wikipedia.org/wiki/Tim_Berners-Lee) invented the World Wide Web in 1989
To check if one of your accounts has been compromised, you can use [Have I Been Pwned](https://haveibeenpwned.com)
Try out [Zellij](https://zellij.dev/), its a really cool terminal multiplexer!
tvguho.pbz/pbxb7
u just got hit with the 404, ouch
u so lost rn
vim is NOT the greatest editor. It is the greatest thing, (period) ✨
[Vinton Cerf](https://en.wikipedia.org/wiki/Vint_Cerf) is the father of TCP/IP
Wanna pimp your Unix toolbox a little bit? Checkout [Modern Unix](https://github.com/ibraheemdev/modern-unix) tools
Want some cool-looking fonts with awesome icons? Checkout [Nerd Fonts](https://www.nerdfonts.com/)
want to easily make terminal GIFs? Checkout [VHS](https://github.com/charmbracelet/vhs) (by the same people who made [gum](https://github.com/charmbracelet/gum))
[We, Programmers](https://www.amazon.com/We-Programmers-Chronicle-Coders-Robert/dp/0135344263) is a book by Robert C. Martin which goes over the history of programming from Ada to AI
weqiejoiJW IEjOIEJ IJEQIOJIE JQIEJijsdjfrksaf jiwejr iojreoiqjroiejd riojoijweo
where u tryna get?
Why 404? Why not 504? Thats because of HTTP status codes. 4XX means its YOUR fucking fault you ended up here
**WHY IS HTTP/0.9 NOT WORKING RIGHT NOW?????** *(you ask)*<br/> well... Imma bring it bak at som point, promis
Why use Linux? Maybe so that you don't have to go through setting up a Microsoft account to use your ***"""PER-SO-NAL"""*** computer ¯\_(ツ)_/¯
wiejkqoiejiqojeoqwewqiejwoq
woooooooh, learn to type maybe?
You appear to be lost
You can stack 64 doors but you can only hold 16 ender pearls. *wtf Minecraft*
You really gotta try [tealdeer](https://github.com/tealdeer-rs/tealdeer?tab=readme-ov-file)
⚠️ Your RAM is insufficient to load this page, you can [download some now](https://downloadmoreram.com/)
You should be going now.
You should enable sudo insults on your Linux rn: [https://itsfoss.com/sudo-insult-linux/](https://itsfoss.com/sudo-insult-linux/)
You should give a try to Vim motions, at least once in your life. <br/> It might not be for you but it changed my entire programming experience.
Use 5 Vim macros a day to keep the [Linux guy](https://github.com/Coko7) away.
[zoxide](https://github.com/ajeetdsouza/zoxide) + [yazi](https://github.com/sxyazi/yazi) is **Perfection**
If you are in need of some icons, checkout [dashboardicons.com](https://dashboardicons.com)
There are at least [1007 different programming languages](https://github.com/leachim6/hello-world)
(ノಠ益ಠ)ノ彡┻━┻
(ノಠ益ಠ)ノ彡┻━┻ (hey, its me)
If you are into programming, you might wanna read [The Pragmatic Programmer](https://pragprog.com/titles/tpp20/the-pragmatic-programmer-20th-anniversary-edition/) at some point
Ever struggled with building habits? Checkout [Atomic Habits](https://jamesclear.com/atomic-habits) by James Clear
<span style="font-size: 5em;">🧘</span><br/> [Meditations](https://en.wikipedia.org/wiki/Meditations)
Current datetime is **18/10/25 - 10:17** *(at least when I am writing this)*
[The Mother of All Demos](https://www.youtube.com/watch?v=yJDv-zdhzMY) by Douglas Engelbart (1968)
<span style="font-size: 5em;">⌨️</span><br/> Google *"[Keyboards](https://github.com/google/mozc-devices)"*
Cool event: [Journées du Logiciel Libre](https://www.jdll.org/)
[Omarchy](https://omarchy.org/) is kinda nuts 🥜
Sync your shell history with [atuin.sh](https://atuin.sh/) *(self-hosting available)*
[kyber.media](https://kyber.media/)
Look how nice those CSS effects look: [poke-holo.smiley.me](https://poke-holo.simey.me)
[ZEVENT](https://zevent.fr/) is an awesome french charity event 💚
[Speedons](https://speedons.fr/) is a french version of [GDQ](https://crowd.gamesdonequick.com/) and it fucking rules 🧡
Ever heard of the [Trolley problem](https://en.wikipedia.org/wiki/Trolley_problem) 🚎? <br/> Checkout [Absurd Trolley Problems](https://neal.fun/absurd-trolley-problems/)
[neal.fun](https://neal.fun/) is a fun way to kill time 😀
Ever heard of [Nushell](https://www.nushell.sh/)?
Btw, you can order coffee from your terminal: [terminal.shop](https://www.terminal.shop) ☕
Ever heard of [SSH](https://en.wikipedia.org/wiki/Secure_Shell)? I would not be able to manage this site without it.
**English:** How are you doing? *I am doing fine, what about you?* Doing good. <br/> **French**: Ça va? *Ça va. Ça va?* Ça va.
How much time did I spend writing these messages rather than working on this website? <br/>Ever heard of [TREE(3)](https://en.wikipedia.org/wiki/Kruskal%27s_tree_theorem)? <br/> There's your answer.
Probably one of the most intuitive videos on how [Diffie-Hellman](https://en.wikipedia.org/wiki/Diffie%E2%80%93Hellman_key_exchange) secret key exchange works: [youtu.be/NmM9HA2MQGI](https://youtu.be/NmM9HA2MQGI)
Watch [this awesome vid](https://youtu.be/YQw124CtvO0) on [RSA](https://en.wikipedia.org/wiki/RSA_cryptosystem), featuring [Ron Rivest](https://en.wikipedia.org/wiki/Ron_Rivest), co-inventor of RSA itself.
